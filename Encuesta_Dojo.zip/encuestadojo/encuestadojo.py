from flask import Flask, render_template, request, session, redirect

app = Flask(__name__)
app.secret_key = "clave_secreta" 

@app.route("/", methods=["GET"])
def formulario():
    session.clear()  
    return render_template("formulario.html")

@app.route("/result", methods=["POST"])
def resultado():
    session['nombre'] = request.form["nombre"]
    session['localidad'] = request.form["localidad"]
    session['lenguajes'] = request.form["lenguajes"]
    session['comentario'] = request.form["comentario"]
    return redirect("/mostrar_resultado")

@app.route("/mostrar_resultado", methods=["GET"])
def mostrar_resultado():
    return render_template("resultado.html")

@app.route("/regresar", methods=["GET"])
def regresar():
    session.clear()  # Limpiar datos de sesión
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)